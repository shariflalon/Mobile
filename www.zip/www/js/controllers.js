angular.module('jobmanager.controllers', [])

    .controller('SignInCtrl', function ($scope, $state, $ionicPopup, $ionicHistory, $loginService) {
        $scope.user = {};

        $scope.signIn = function (user) {
            var alertPopup;
            $loginService.login(user.username, user.password).then(function (data) {
                if (data.success) {
                    $ionicHistory.nextViewOptions({
                        disableAnimate: true,
                        disableBack: true
                    });
                    $state.go('tab.jobs');
                } else {
                    alertPopup = $ionicPopup.alert({
                        title: 'Login failed!',
                        template: data.msg
                    });
                }
            }, function (message) {
                alertPopup = $ionicPopup.alert({
                    title: 'Login failed!',
                    template: message
                });
            });
        };
    })

    .controller('SyncInCtrl', function ($scope, $state, $ionicPopup, $loginService, $syncService) {
        var alertPopup, currentUser,
            initialize = function () {
                console.log("initialization");
                $scope.company = "Comany data fectching...";
                $scope.order = "Order data fectching...";

                currentUser = $loginService.getCurrentUser();
                $syncService.syncIn(currentUser.user, currentUser.password).then(function (data) {
                    if (data.success) {
                        $scope.company = "Comany data synced";
                        $scope.order = "Order data synced";
                    } else {
                        alertPopup = $ionicPopup.alert({
                            title: 'Sync In failed!',
                            template: data.msg
                        });
                    }
                }, function (message) {
                    alertPopup = $ionicPopup.alert({
                        title: 'Sync In failed!',
                        template: message
                    });
                });
            };

        initialize();
    })

    .controller('JobsCtrl', function ($scope, $state, $ionicPopup, $companyOrder) {
        $companyOrder.all().then(function (data) {
            $scope.jobs = data;
        });
    })

    .controller('JobDetailCtrl', function ($scope, $stateParams, $companyOrder) {
        $companyOrder.getById($stateParams.id).then(function (data) {
            $scope.job = data;
        });
    })

    .controller('JobSignatureCtrl', function ($scope, $stateParams, $companyOrder) {
        $companyOrder.getById($stateParams.id).then(function (data) {
            $scope.job = data;
        });
    })

    .controller('JobChecklistCtrl', function ($scope, $stateParams, $companyOrder) {
        $companyOrder.getById($stateParams.id).then(function (data) {
            $scope.job = data;
        });
    })

    .controller('JobFeedbackCtrl', function ($scope, $stateParams, $companyOrder) {
        var typecomment = $stateParams.type == "customer" ? "Customer Note" : $stateParams.type == "internal" ? "Internal Notes" : "HVAC Notes";
        $scope.header = typecomment;
        $scope.save = function (comment) {
            var objc;
            if ($stateParams.type == "customer")
                objc = { customers_comments: comment };
            else if ($stateParams.type == "internal")
                objc = { engineers_notes: comment };
            else
                objc = { hvac_notes: comment };
            $companyOrder.update(objc, $stateParams.id).then(function (data) {
                // $scope.jobs = data;
                if (data.success) {
                    $scope.header = "Comment Updated Successfully";
                }
            });
        };

        $companyOrder.getById($stateParams.id).then(function (data) {
            $scope.job = data;
        });
    });